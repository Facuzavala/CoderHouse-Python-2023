from setuptools import setup

setup(
    name="Paquete",
    version="1.0",
    author="Facundo Zavala",
    description="Pre-entrega nro 2, acerca de clases, modulos y paquetes",
    author_email="Facu.zava@coderhouse.com",
    packages=["Paquete"]
)